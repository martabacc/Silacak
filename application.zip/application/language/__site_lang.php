<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['site_title'] = 'Sistem Informasi Pelacakan';
$lang['master_filter'] = 'Filter';
$lang['master_yes'] = 'Yes';
$lang['master_no'] = 'No';
$lang['master_all'] = 'All';
$lang['master_none'] = 'Please Select';
$lang['breadcrumb_home'] = 'Home';