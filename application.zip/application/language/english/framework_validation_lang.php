<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['form_validation_valid_date'] = 'The {field} field must contain valid date.';
$lang['form_validation_valid_datetime'] = 'The {field} field must contain valid datetime.';