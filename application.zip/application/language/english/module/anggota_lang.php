<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['module_title'] = 'Anggota Publikasi';
$lang['module_subtitle'] = 'Manajemen';
$lang['module_description'] = 'Modul ini berfungsi untuk manajemen master anggota publiksi';
$lang['module_master'] = 'Daftar Anggota Publikasi';
$lang['module_detail'] = 'Sunting Anggota Publikasi';
$lang['module_pegawai_master'] = 'Daftar Pengarang';
$lang['module_publikasi_master'] = 'Daftar Publikasi';

$lang['ang_id'] = 'ID';
$lang['ang_id_help'] = '';
$lang['ang_pegawai'] = 'Nama Pengarang';
$lang['ang_pegawai_help'] = '';
$lang['ang_publikasi'] = 'Publikasi';
$lang['ang_publikasi_help'] = '';
$lang['ang_sebagai'] = 'Pengarang ke-';
$lang['ang_sebagai_help'] = '';

$lang['ang_no'] = 'No';
