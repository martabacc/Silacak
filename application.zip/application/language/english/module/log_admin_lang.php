<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['module_title'] = 'Log Kegiatan';
$lang['module_subtitle'] = 'Manajemen';
$lang['module_description'] = 'Modul ini berfungsi untuk manajemen master log kegiatan';
$lang['module_master'] = 'Daftar Log Kegiatan';
$lang['module_detail'] = 'Detail Log Kegiatan';

$lang['adm_id'] = 'ID';
$lang['adm_id_help'] = '';
$lang['adm_pengguna'] = 'Pengguna';
$lang['adm_pengguna_help'] = '';
$lang['adm_tanggal'] = 'Tanggal';
$lang['adm_tanggal_help'] = '';
$lang['adm_aktivitas'] = 'Aktivitas';
$lang['adm_aktivitas_help'] = '';
$lang['adm_keterangan'] = 'Keterangan';
$lang['adm_keterangan_help'] = '';

$lang['adm_update_setting'] = 'Sunting Konfigurasi';