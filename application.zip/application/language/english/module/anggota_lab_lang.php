<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['module_title'] = 'Anggota Laboratorium';
$lang['module_subtitle'] = 'Manajemen';
$lang['module_description'] = 'Modul ini berfungsi untuk manajemen master anggota laboratorium';
$lang['module_master'] = 'Daftar Anggota Laboratorium';
$lang['module_detail'] = 'Detail Anggota Laboratorium';

$lang['alb_id'] = 'ID';
$lang['alb_id_help'] = '';
$lang['alb_pegawai'] = 'Dosen';
$lang['alb_pegawai_help'] = '';
$lang['alb_laboratorium'] = 'Laboratorium';
$lang['alb_laboratorium_help'] = '';
$lang['alb_status_ketua'] = 'Status Ketua';
$lang['alb_status_ketua_help'] = '';
$lang['alb_periode_aktif'] = 'Periode Aktif';
$lang['alb_periode_aktif_help'] = '';