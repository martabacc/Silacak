<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['cit_jumlah'] = 'Jumlah Dikutip';
$lang['cit_tahun'] = 'Tahun';
