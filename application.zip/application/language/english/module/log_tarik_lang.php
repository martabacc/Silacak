<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['module_title'] = 'Log Periode Pengunduhan';
$lang['module_subtitle'] = 'Manajemen';
$lang['module_description'] = 'Modul ini berfungsi untuk manajemen master log Periode Pengunduhan';
$lang['module_master'] = 'Daftar Log Periode Pengunduhan';
$lang['module_detail'] = 'Sunting Log Periode Pengunduhan';

$lang['tar_id'] = 'ID';
$lang['tar_id_help'] = '';
$lang['tar_tanggal'] = 'Tanggal';
$lang['tar_tanggal_help'] = '';
$lang['tar_jenis'] = 'Jenis Unduh Data';
$lang['tar_jenis_help'] = '';
$lang['tar_keterangan'] = 'Keterangan';
$lang['tar_keterangan_help'] = '';
$lang['tar_status'] = 'Status';
$lang['tar_status_help'] = '';

$lang['tar_filterstart'] = 'Tanggal';
$lang['tar_filterend'] = 'Sampai';