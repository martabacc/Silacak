<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/*
 * Custom Model for custom query ex: report
 * Generated with Doni's Generator
 *
 * @author: Doni Setio Pambudi (donisp06@gmail.com)
 */
class M_custom extends CI_Model {
	function __construct()
	{ parent::__construct(); }
	//custom query example
	/*function custom_query($query){
		$query_result = $this->db->query($query);
		return $query_result->result();
	}*/
}