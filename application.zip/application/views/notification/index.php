<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="row">
	<div class="col-md-12">
		<div id="master-page">
            <p style="font-size:15px;">
            Kepada Yth pengguna Sistem Informasi Pelacakan, 
            
            Perubahan dalam aplikasi antara lain :
            <hr>

                <h4>
                    5 Desember 2016
                </h4>
            <ol>
                <li>
                    Semua menu laporan dipindahkan ke menu Laporan
                </li>
                <li>
                     Menu Data ISSN dan Scopus Dipindahkan ke Menu Klasifikasi Data.
                </li>
                <li>
                     Untuk proses penambahan data Scopus, klasifikasi ISSN maupun Scopus sedang dalam proses pengerjaan. Mohon maaf jika ada menu yang belum berfungsi dalam proses pengerjaan tersebut.
                </li>
            </ol>

            </p>
			
		</div>
	</div>
</div>