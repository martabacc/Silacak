<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="row">
	<div class="col-md-12">
		<div class="note note-danger">
			<h4 class="block"><?php echo $this->lang->line('error_subtitle'); ?></h4>
			<p><?php echo $error; ?></p>
		</div>
	</div>
</div>