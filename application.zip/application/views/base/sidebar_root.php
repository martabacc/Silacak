<li>
    <a href="<?php echo base_url(); ?>pengguna" module="pengguna">
        <i class="fa fa-book"></i>
        <span class="title">Pengguna</span>
    </a>
</li>
<!-- <li>
    <a href="<?php echo base_url(); ?>frameworksetting" module="frameworksetting">
        <i class="fa fa-cogs"></i>
        <span class="title">Setting</span>
    </a>
</li> -->